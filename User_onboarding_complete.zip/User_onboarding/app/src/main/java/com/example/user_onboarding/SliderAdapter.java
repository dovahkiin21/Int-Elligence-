package com.example.user_onboarding;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

public class SliderAdapter extends PagerAdapter {
     Context context;
     LayoutInflater layoutInflater;

     public SliderAdapter(Context context){
         this.context = context;
     }
     /* The following array contains the description of each button that
        changes when a slide is changed.
      */
      public String[] description_text = {
              "Press this button or  say \"OBJECT\" to detect an object in front of your camera" ,
             "Press this button or  say \"TEXT\" to recognise the text in front of your camera" ,
             "Press this button to toggle voice commands by shaking your phone" ,
             "Press this button or  say \"SETTINGS\" to open up the settings menu"
     };

    @Override
    public int getCount() {
        return description_text.length;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {

        layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.slide_layout,container,false);

        TextView button_description = view.findViewById(R.id.tutorial_text1);
        TextView button_description_2 = view.findViewById(R.id.tutorial_text2);

        button_description.setText(description_text[position]);
        button_description_2.setText(description_text[position]);

        container.addView(view);

        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {

        container.removeView((View) object);
    }
}
