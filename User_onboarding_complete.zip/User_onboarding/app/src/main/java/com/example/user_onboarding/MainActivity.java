package com.example.user_onboarding;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    ViewPager slideViewPager;
    SliderAdapter sliderAdapter;

    Button tour_button;
    Button next_end_button;
    Button skip_button;
    Button back_button;

    ImageView objectDetc, textRecon, voiceCom , settings;

    TextView tutorial_text1 , tutorial_text2;

    int currentPage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        slideViewPager = findViewById(R.id.viewpager);
        sliderAdapter = new SliderAdapter(this);
        slideViewPager.setAdapter(sliderAdapter);

        tour_button = findViewById(R.id.tour_button);
        next_end_button = findViewById(R.id.next_end_button);
        skip_button = findViewById(R.id.skip_button);
        back_button = findViewById(R.id.back_button);

        tutorial_text1 = findViewById(R.id.tutorial_text1);
        tutorial_text2 = findViewById(R.id.tutorial_text2);

        objectDetc = findViewById(R.id.objectDetc);
        textRecon = findViewById(R.id.textRecon);
        voiceCom = findViewById(R.id.voiceCom);
        settings = findViewById(R.id.settings);



    }

    ViewPager.OnPageChangeListener viewListener = new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(int position) {

            currentPage = position;

            switch (currentPage)
            {
                case 0:
                    tutorial_text1.setVisibility(View.VISIBLE);
                    tutorial_text2.setVisibility(View.INVISIBLE);
                    objectDetc.setVisibility(View.VISIBLE);
                    textRecon.setImageAlpha(25);
                    voiceCom.setVisibility(View.INVISIBLE);
                    settings.setImageAlpha(View.INVISIBLE);
                    skip_button.setEnabled(true);
                    skip_button.setVisibility(View.VISIBLE);
                    next_end_button.setText("Next");
                    break;

                case 1:
                    tutorial_text1.setVisibility(View.VISIBLE);
                    tutorial_text2.setVisibility(View.INVISIBLE);
                    objectDetc.setImageAlpha(25);
                    textRecon.setVisibility(View.VISIBLE);
                    voiceCom.setVisibility(View.INVISIBLE);
                    settings.setImageAlpha(View.INVISIBLE);
                    skip_button.setEnabled(true);
                    skip_button.setVisibility(View.VISIBLE);
                    next_end_button.setText("Next");
                    break;

                case 2:
                    tutorial_text1.setVisibility(View.INVISIBLE);
                    tutorial_text2.setVisibility(View.VISIBLE);
                    objectDetc.setVisibility(View.INVISIBLE);
                    textRecon.setVisibility(View.INVISIBLE);
                    voiceCom.setVisibility(View.VISIBLE);
                    settings.setImageAlpha(25);
                    skip_button.setEnabled(true);
                    skip_button.setVisibility(View.VISIBLE);
                    next_end_button.setText("Next");
                    break;

                case 3:
                    tutorial_text1.setVisibility(View.INVISIBLE);
                    tutorial_text2.setVisibility(View.VISIBLE);
                    objectDetc.setVisibility(View.INVISIBLE);
                    textRecon.setVisibility(View.INVISIBLE);
                    settings.setVisibility(View.VISIBLE);
                    voiceCom.setImageAlpha(25);
                    skip_button.setEnabled(false);
                    skip_button.setVisibility(View.INVISIBLE);
                    next_end_button.setText("End");
                    break;

            }
        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    };
}
