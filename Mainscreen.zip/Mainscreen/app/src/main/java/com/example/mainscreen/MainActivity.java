package com.example.mainscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button objectButton,textButton,voiceButton,settingsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        objectButton=findViewById(R.id.object_button);
        textButton=findViewById(R.id.text_button);
        voiceButton=findViewById(R.id.voice_button);
        settingsButton=findViewById(R.id.settings_button);
    }
}
